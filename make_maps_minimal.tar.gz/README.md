# proj-an
code and scripts for making 2D projected maps from SPH simulations (Eagle and some similar ones), analyzing those maps, and analyzing specwizard outputs

---------------------------------------------------------------------------------------------------
main files for making projections:
---------------------------------------------------------------------------------------------------
make_maps_v3_master contains code for projecting Eagle data into 2d maps
it dpeends on some of the files here, and most of the other focus on analysis of these 2D maps,
sometimes in combination with other data (specwizard outputs or halo catalogues)

--------------------------------------------------------------------------------------------------
warning:
--------------------------------------------------------------------------------------------------
This repo is mainly for me to sync up in-progress work. Much of this code is untested, 
half-finished projects I abandoned, or work in progress


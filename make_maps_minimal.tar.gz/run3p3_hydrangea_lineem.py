#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Thu Aug  1 14:13:02 2019

@author: wijers
"""

hpar = 0.6777
#aexp = 0.7397011977358829 
  

import numpy as np
import sys
import make_maps_v3_master as mmap

# read-in
numslices = int(sys.argv[2])
sliceind = int(sys.argv[1])

# basic box and projection region parameters (splitting into (sub)slices is done later)
simnum = 28
snapnum = 26 #z=0.1, same as the Eagle projections

var='auto'
npix_x=1600
npix_y=1600
simulation = 'c-eagle-hydrangea'

# get the scalings needed to center on the halos

L_x = 6.25
L_y = 6.25
L_z = 14. 
centre = 'cluster' # cluster -> use the most masive halo COP
axis = 'z'
LsinMpc = True

periodic = False
velcut = False
kernel = 'C2'

parttype = '0'

ptypeW = 'emission'
ionW = 'o8'
abundsW = 'Pt'
quantityW = None
excludeSFRW = 'T4'

ptypeQ = None
ionQ = None
abundsQ = 'auto'
quantityQ = 'Temperature'
excludeSFRQ = 'T4'


saveres = True
log = True
misc = None

       
if centre == 'cluster':
    gf = mmap.pc.Simfile(simnum, snapnum, var, file_type='sub', simulation=simulation)
    cop = gf.readarray('Subhalo/CentreOfPotential', rawunits=True)
    # according to Yannick, just using the central subhalo of the most massive halo (subhalo 0) should work just fine out to z~2, when the main progenitor is no longer necessarily the most massive halo
    print(cop.shape)
    print(cop)
    centre = cop[0, :] / gf.h # convert to cMpc units expected by make_map;  
    cop = list(cop)
         

# box slicing using input parameters (no need to adjust per run)
if axis == 'z':
    L_z = L_z/np.float(numslices) # split into numslices slices along projection axis
    centre[2] = centre[2] - (numslices+1.)*L_z/2. + sliceind*L_z  
if axis == 'x':
    L_x = L_x/np.float(numslices) # split into numslices slices along projection axis
    centre[0] = centre[0] - (numslices+1.)*L_x/2. + sliceind*L_x  
if axis == 'y':
    L_y = L_y/np.float(numslices) # split into numslices slices along projection axis
    centre[1] = centre[1] - (numslices+1.)*L_y/2. + sliceind*L_y      

# document input parameters:(processed input is also printed by make_map)
print('\n')

print('Overview of function input parameters: [cMpc] where applicable \n')
print('simnum: \t %s' %simnum)
print('snapnum: \t %i' % snapnum)
print('centre: \t %s' %str(centre))
print('L_x, L_y, L_z: \t %f, %f, %f \n' %(L_x, L_y, L_z))

print('kernel: \t %s' %kernel)
print('axis: \t %s' %axis)
print('periodic: \t %s' %str(periodic))
print('npix_x,npix_y: \t %i, %i \n' %(npix_x, npix_y))

print('saveres: \t %s' %str(saveres))
print('log: \t %s' %str(True))

print('\n')

# function call
mmap.make_map(simnum, snapnum, centre, L_x, L_y, L_z, npix_x, npix_y, \
         ptypeW,\
         ionW=ionW, abundsW=abundsW, quantityW=quantityW,\
         ionQ=ionQ, abundsQ=abundsQ, quantityQ=quantityQ, ptypeQ=ptypeQ,\
         excludeSFRW=excludeSFRW, excludeSFRQ=excludeSFRQ, parttype=parttype,\
         simulation=simulation, LsinMpc=LsinMpc,\
         theta=0.0, phi=0.0, psi=0.0, \
         var=var, axis=axis,log=log, velcut=velcut,\
         periodic=periodic, kernel=kernel, saveres=saveres,\
         misc=misc, ompproj=True, nameonly=False, numslices=None,\
         halosel=None, kwargs_halosel=None)